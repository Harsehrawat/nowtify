package com.example.nowtify;

import retrofit2.http.GET;
public interface RetrofitAPI {
    @GET
}
